"use client";

import { useState } from "react";
import { Plus, X } from "lucide-react";
import { createTaskAction } from "@/app/(app)/tasks/actions";
import type { HouseholdMember } from "@/lib/supabase/types";

// Bottom sheet rather than a separate page — adding a task is a frequent,
// quick action that shouldn't cost a navigation round trip away from the
// list (same "minimal clicks" reasoning as the shopping list's inline add).
export function NewTaskSheet({ currentMember, partner }: { currentMember: HouseholdMember; partner: HouseholdMember | null }) {
  const [open, setOpen] = useState(false);
  const today = new Date().toISOString().slice(0, 10);

  async function handleSubmit(formData: FormData) {
    await createTaskAction(formData);
    setOpen(false);
  }

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="mt-1 flex w-full items-center justify-center gap-1.5 rounded-xl border border-dashed py-3 text-[13px]"
        style={{ borderColor: "var(--border-strong)", color: "var(--text-secondary)" }}
      >
        <Plus size={14} aria-hidden="true" /> Nova obaveza
      </button>

      {open && (
        <div
          className="fixed inset-0 z-30 flex items-end justify-center"
          style={{ background: "rgba(0,0,0,0.4)" }}
          onClick={() => setOpen(false)}
        >
          <form
            action={handleSubmit}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[420px] rounded-t-3xl px-4 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] pt-2"
            style={{ background: "var(--surface-1)" }}
          >
            <div className="flex items-center justify-between py-3">
              <span className="text-[15px] font-medium" style={{ color: "var(--text-primary)" }}>
                Nova obaveza
              </span>
              <button
                type="button"
                onClick={() => setOpen(false)}
                aria-label="Zatvori"
                className="flex h-8 w-8 items-center justify-center border-0"
                style={{ background: "transparent" }}
              >
                <X size={18} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
              </button>
            </div>

            <div className="flex flex-col gap-3 pb-2">
              <input name="title" placeholder="Naziv obaveze" required autoFocus />

              <div>
                <label className="mb-1 block text-[12px]" style={{ color: "var(--text-secondary)" }}>
                  Datum
                </label>
                <input name="dueDate" type="date" defaultValue={today} required />
              </div>

              <div>
                <label className="mb-1 block text-[12px]" style={{ color: "var(--text-secondary)" }}>
                  Ponavljanje
                </label>
                <select name="recurrence" defaultValue="none">
                  <option value="none">Jednokratno</option>
                  <option value="daily">Svaki dan</option>
                  <option value="weekly">Svake nedelje</option>
                  <option value="monthly">Svakog meseca</option>
                </select>
              </div>

              <div>
                <label className="mb-1 block text-[12px]" style={{ color: "var(--text-secondary)" }}>
                  Ko je zadužen
                </label>
                <select name="assignment" defaultValue="unassigned">
                  <option value="unassigned">Niko određen</option>
                  <option value="me">{currentMember.display_name}</option>
                  {partner && <option value="partner">{partner.display_name}</option>}
                  <option value="everyone">Oboje</option>
                </select>
              </div>

              <button
                type="submit"
                className="mt-1 h-10 border-0 font-medium"
                style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
              >
                Dodaj obavezu
              </button>
            </div>
          </form>
        </div>
      )}
    </>
  );
}
