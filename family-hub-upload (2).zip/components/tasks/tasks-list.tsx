"use client";

import { useState } from "react";
import { TaskCard } from "@/components/today/task-card";
import type { Task, HouseholdMember } from "@/lib/supabase/types";
import { groupTasks } from "@/lib/tasks/group-tasks";

type Filter = "all" | "oneoff" | "recurring";

function formatDate(dateStr: string) {
  return new Date(dateStr).toLocaleDateString("sr-RS", { day: "numeric", month: "short" });
}

export function TasksList({ tasks, members }: { tasks: Task[]; members: HouseholdMember[] }) {
  const [filter, setFilter] = useState<Filter>("all");
  const [, setOpenTaskId] = useState<string | null>(null);

  const filtered = tasks.filter((t) => {
    if (filter === "oneoff") return !t.is_recurring;
    if (filter === "recurring") return t.is_recurring;
    return true;
  });

  const groups = groupTasks(filtered);
  const hasNothing = groups.overdue.length + groups.today.length + groups.tomorrow.length + groups.later.length === 0;

  return (
    <div className="flex flex-col gap-1">
      <div className="flex gap-1.5">
        <FilterButton active={filter === "all"} onClick={() => setFilter("all")} label="Sve" />
        <FilterButton active={filter === "oneoff"} onClick={() => setFilter("oneoff")} label="Jednokratne" />
        <FilterButton active={filter === "recurring"} onClick={() => setFilter("recurring")} label="Ponavljajuće" />
      </div>

      <div className="mt-3 flex flex-col gap-4">
        {hasNothing && (
          <p className="py-10 text-center text-[13px]" style={{ color: "var(--text-muted)" }}>
            Nema obaveza u ovoj kategoriji.
          </p>
        )}

        <TaskSection label="Zakasnelo" tasks={groups.overdue} members={members} variant="overdue" onOpen={setOpenTaskId} />
        <TaskSection label="Danas" tasks={groups.today} members={members} onOpen={setOpenTaskId} />
        <TaskSection label="Sutra" tasks={groups.tomorrow} members={members} onOpen={setOpenTaskId} />
        <TaskSection label="Kasnije" tasks={groups.later} members={members} onOpen={setOpenTaskId} showDate />
      </div>
    </div>
  );
}

function TaskSection({
  label,
  tasks,
  members,
  variant,
  onOpen,
  showDate,
}: {
  label: string;
  tasks: Task[];
  members: HouseholdMember[];
  variant?: "default" | "overdue";
  onOpen: (id: string) => void;
  showDate?: boolean;
}) {
  if (tasks.length === 0) return null;

  return (
    <section>
      <p
        className="mb-2 text-[12px] font-medium uppercase tracking-wide"
        style={{ color: variant === "overdue" ? "var(--text-danger)" : "var(--text-muted)" }}
      >
        {label}
      </p>
      <div className="flex flex-col gap-2">
        {tasks.map((task) => (
          <div key={task.id} className="relative">
            <TaskCard task={task} members={members} variant={variant} onOpenDetails={onOpen} />
            {showDate && task.due_date && (
              <span
                className="pointer-events-none absolute right-12 top-1/2 -translate-y-1/2 text-[12px]"
                style={{ color: "var(--text-muted)" }}
              >
                {formatDate(task.due_date)}
              </span>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

function FilterButton({ active, onClick, label }: { active: boolean; onClick: () => void; label: string }) {
  return (
    <button
      onClick={onClick}
      className="border-0 px-3 py-1.5 text-[13px]"
      style={{
        background: active ? "var(--fill-primary)" : "var(--surface-2)",
        color: active ? "var(--on-primary)" : "var(--text-secondary)",
        borderColor: "var(--border)",
      }}
    >
      {label}
    </button>
  );
}
