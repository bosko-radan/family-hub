"use client";

import { useRef } from "react";
import { Plus } from "lucide-react";
import { addShoppingItemAction } from "@/app/(app)/shopping/item-actions";

// Two fields (name + optional quantity) on one row rather than a modal —
// matches "minimal clicks": typing a name and quantity then tapping Add
// is the whole interaction, no navigation away from the list.
export function AddItemForm({ listId }: { listId: string }) {
  const formRef = useRef<HTMLFormElement>(null);

  async function handleSubmit(formData: FormData) {
    await addShoppingItemAction(listId, formData);
    formRef.current?.reset();
  }

  return (
    <form ref={formRef} action={handleSubmit} className="mt-2 flex gap-2">
      <input name="name" placeholder="Dodaj stavku…" required autoFocus className="flex-1" />
      <input name="quantity" placeholder="kol." className="w-16 text-center" />
      <button
        type="submit"
        aria-label="Dodaj"
        className="flex h-10 w-10 shrink-0 items-center justify-center border-0"
        style={{ background: "var(--fill-primary)" }}
      >
        <Plus size={18} style={{ color: "var(--on-primary)" }} aria-hidden="true" />
      </button>
    </form>
  );
}
