"use client";

import { useState, useEffect } from "react";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  verticalListSortingStrategy,
  useSortable,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ShoppingItemRow } from "@/components/shopping/shopping-item-row";
import { reorderShoppingItemsAction } from "@/app/(app)/shopping/item-actions";
import type { ShoppingItem } from "@/lib/supabase/types";

function SortableRow({ item, listId }: { item: ShoppingItem; listId: string }) {
  const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id: item.id });

  return (
    <div ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition }}>
      <ShoppingItemRow item={item} listId={listId} dragHandleProps={{ ...attributes, ...listeners }} />
    </div>
  );
}

// Splits items into unchecked (sortable, on top) and checked (static, at
// the bottom) — matches the product decision that checking an item moves
// it out of the way rather than leaving it cluttering the active list.
// Only the unchecked group is drag-reorderable; reordering checked items
// has no purpose since they're about to be cleared.
export function SortableShoppingList({ items, listId }: { items: ShoppingItem[]; listId: string }) {
  const unchecked = items.filter((i) => !i.checked_at);
  const checked = items.filter((i) => i.checked_at);

  const [orderedIds, setOrderedIds] = useState(unchecked.map((i) => i.id));
  useEffect(() => {
    setOrderedIds(unchecked.map((i) => i.id));
    // Re-sync local drag order whenever the server-provided item set
    // changes (new item added, item checked off) — local state only
    // exists to make dragging feel instant, not as a source of truth.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items.length, unchecked.map((i) => i.id).join(",")]);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = orderedIds.indexOf(active.id as string);
    const newIndex = orderedIds.indexOf(over.id as string);
    const next = arrayMove(orderedIds, oldIndex, newIndex);
    setOrderedIds(next);
    reorderShoppingItemsAction(listId, next);
  }

  const orderedUnchecked = orderedIds
    .map((id) => unchecked.find((i) => i.id === id))
    .filter((i): i is ShoppingItem => !!i);

  return (
    <div className="flex flex-col gap-2">
      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={orderedIds} strategy={verticalListSortingStrategy}>
          {orderedUnchecked.map((item) => (
            <SortableRow key={item.id} item={item} listId={listId} />
          ))}
        </SortableContext>
      </DndContext>

      {checked.length > 0 && (
        <div className="mt-2 flex flex-col gap-2 border-t-[0.5px] pt-2" style={{ borderColor: "var(--border)" }}>
          {checked.map((item) => (
            <ShoppingItemRow key={item.id} item={item} listId={listId} />
          ))}
        </div>
      )}
    </div>
  );
}
