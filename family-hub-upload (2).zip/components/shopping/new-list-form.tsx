"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { createShoppingListAction } from "@/app/(app)/shopping/list-actions";

export function NewListForm() {
  const [open, setOpen] = useState(false);

  if (!open) {
    return (
      <button
        onClick={() => setOpen(true)}
        className="mt-1 flex w-full items-center justify-center gap-1.5 rounded-xl border border-dashed py-3 text-[13px]"
        style={{ borderColor: "var(--border-strong)", color: "var(--text-secondary)" }}
      >
        <Plus size={14} aria-hidden="true" /> Nova lista
      </button>
    );
  }

  return (
    <form action={createShoppingListAction} className="flex gap-2">
      <input
        name="name"
        placeholder="Naziv liste (npr. Market)"
        autoFocus
        required
        className="flex-1"
      />
      <button
        type="submit"
        className="h-10 shrink-0 border-0 px-4 text-[13px] font-medium"
        style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
      >
        Dodaj
      </button>
    </form>
  );
}
