"use client";

import { useTransition } from "react";
import { GripVertical } from "lucide-react";
import { toggleShoppingItemAction } from "@/app/(app)/shopping/item-actions";
import type { ShoppingItem } from "@/lib/supabase/types";

interface ShoppingItemRowProps {
  item: ShoppingItem;
  listId: string;
  dragHandleProps?: React.HTMLAttributes<HTMLButtonElement>;
}

export function ShoppingItemRow({ item, listId, dragHandleProps }: ShoppingItemRowProps) {
  const [isPending, startTransition] = useTransition();

  function handleToggle() {
    startTransition(() => {
      toggleShoppingItemAction(item.id, listId);
    });
  }

  return (
    <div
      className="flex items-center gap-2.5 rounded-xl border-[0.5px] px-3 py-2.5"
      style={{ background: "var(--surface-2)", borderColor: "var(--border)", opacity: isPending ? 0.6 : 1 }}
    >
      <button
        {...dragHandleProps}
        aria-label="Promeni redosled"
        className="cursor-grab touch-none border-0 p-0"
        style={{ background: "transparent" }}
      >
        <GripVertical size={14} style={{ color: "var(--text-muted)" }} aria-hidden="true" />
      </button>
      <input
        type="checkbox"
        checked={!!item.checked_at}
        onChange={handleToggle}
        className="h-[17px] w-[17px] shrink-0"
        aria-label={item.checked_at ? "Označeno kao kupljeno" : "Označi kao kupljeno"}
      />
      <span
        className="flex-1 truncate text-[14px]"
        style={{
          color: item.checked_at ? "var(--text-muted)" : "var(--text-primary)",
          textDecoration: item.checked_at ? "line-through" : "none",
        }}
      >
        {item.name}
      </span>
      {item.quantity && (
        <span className="text-[12px]" style={{ color: "var(--text-muted)" }}>
          {item.quantity}
        </span>
      )}
    </div>
  );
}
