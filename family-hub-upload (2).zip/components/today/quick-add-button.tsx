"use client";

import { useState } from "react";
import { Plus, ShoppingCart, CheckSquare, X } from "lucide-react";

const QUICK_ADD_OPTIONS = [
  { icon: ShoppingCart, label: "Stavka za kupovinu", href: "/shopping" },
  { icon: CheckSquare, label: "Obaveza", href: "/tasks" },
] as const;

// Single always-available entry point for adding anything, without first
// navigating into the relevant module — the core "minimal clicks" goal
// from the brief. Routes to each module's own quick-add flow (built when
// that module ships) rather than duplicating four separate forms here.
export function QuickAddButton() {
  const [open, setOpen] = useState(false);

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 z-30 flex items-end justify-center"
          style={{ background: "rgba(0,0,0,0.4)" }}
          onClick={() => setOpen(false)}
        >
          <div
            role="dialog"
            aria-label="Brzo dodaj"
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-[420px] rounded-t-3xl px-4 pb-[calc(env(safe-area-inset-bottom)+1.5rem)] pt-2"
            style={{ background: "var(--surface-1)" }}
          >
            <div className="flex items-center justify-between py-3">
              <span className="text-[15px] font-medium" style={{ color: "var(--text-primary)" }}>
                Brzo dodaj
              </span>
              <button
                onClick={() => setOpen(false)}
                aria-label="Zatvori"
                className="flex h-8 w-8 items-center justify-center border-0"
                style={{ background: "transparent" }}
              >
                <X size={18} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
              </button>
            </div>
            <div className="flex flex-col gap-1 pb-2">
              {QUICK_ADD_OPTIONS.map(({ icon: Icon, label, href }) => (
                <a
                  key={href}
                  href={href}
                  className="flex items-center gap-3 rounded-xl px-3 py-3"
                  style={{ color: "var(--text-primary)" }}
                >
                  <Icon size={20} strokeWidth={1.75} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
                  <span className="text-[14px]">{label}</span>
                </a>
              ))}
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setOpen(true)}
        aria-label="Brzo dodaj"
        className="fixed bottom-24 right-4 z-20 flex h-12 w-12 items-center justify-center rounded-full border-0"
        style={{ background: "var(--fill-primary)" }}
      >
        <Plus size={22} strokeWidth={1.75} style={{ color: "var(--on-primary)" }} aria-hidden="true" />
      </button>
    </>
  );
}
