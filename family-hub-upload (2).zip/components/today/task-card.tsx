"use client";

import { useTransition } from "react";
import { Repeat } from "lucide-react";
import { Avatar, EveryoneAvatar } from "@/components/shared/avatar";
import { toggleTaskCompletionAction } from "@/app/(app)/today/actions";
import type { Task, HouseholdMember } from "@/lib/supabase/types";

interface TaskCardProps {
  task: Task;
  members: HouseholdMember[];
  variant?: "default" | "overdue";
  onOpenDetails: (taskId: string) => void;
}

// A single task row: checkbox toggles completion inline (no navigation),
// tapping the rest of the card opens details — per the explicit product
// decision that these are two different gestures, not one. useTransition
// keeps the checkbox responsive immediately while the server action
// commits, instead of waiting for a full round trip before showing the
// checked state.
export function TaskCard({ task, members, variant = "default", onOpenDetails }: TaskCardProps) {
  const [isPending, startTransition] = useTransition();
  const assignedMember = members.find((m) => m.id === task.assigned_to);

  // Recurring tasks track "done" per cycle via last_completed_for_date —
  // completed_at would otherwise stay null forever for a recurring task,
  // since there's no single permanent completion moment to record.
  const today = new Date().toISOString().slice(0, 10);
  const isDone = task.is_recurring
    ? task.last_completed_for_date === today
    : !!task.completed_at;

  function handleToggle(e: React.MouseEvent) {
    e.stopPropagation();
    startTransition(() => {
      toggleTaskCompletionAction(task.id, task.due_date);
    });
  }

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onOpenDetails(task.id)}
      onKeyDown={(e) => e.key === "Enter" && onOpenDetails(task.id)}
      className="flex cursor-pointer items-center gap-2.5 rounded-xl border-[0.5px] px-3.5 py-3"
      style={{
        background: "var(--surface-2)",
        borderColor: variant === "overdue" ? "var(--border-danger)" : "var(--border)",
        opacity: isPending ? 0.6 : 1,
      }}
    >
      <input
        type="checkbox"
        checked={isDone}
        onChange={() => {}}
        onClick={handleToggle}
        className="h-[18px] w-[18px] shrink-0"
        aria-label={isDone ? "Označeno kao završeno" : "Označi kao završeno"}
      />
      <div className="min-w-0 flex-1">
        <p
          className="truncate text-[14px]"
          style={{
            color: isDone ? "var(--text-muted)" : "var(--text-primary)",
            textDecoration: isDone ? "line-through" : "none",
          }}
        >
          {task.title}
        </p>
        {variant === "overdue" && (
          <p className="mt-0.5 text-[12px]" style={{ color: "var(--text-muted)" }}>
            Juče
          </p>
        )}
      </div>
      {task.is_recurring && (
        <Repeat size={14} strokeWidth={1.75} style={{ color: "var(--text-muted)" }} aria-hidden="true" />
      )}
      {task.assigned_to_everyone ? (
        <EveryoneAvatar size="sm" />
      ) : assignedMember ? (
        <Avatar initial={assignedMember.display_name[0]} color={assignedMember.avatar_color} size="sm" />
      ) : null}
    </div>
  );
}
