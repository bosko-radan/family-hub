import { PartyPopper } from "lucide-react";

// Friendly, not blank — an empty Today view is the happy path (nothing
// urgent today), so the copy frames it as a small win rather than letting
// the screen feel broken or forgotten.
export function TodayEmptyState() {
  return (
    <div className="flex flex-col items-center gap-3 px-6 py-16 text-center">
      <PartyPopper size={32} strokeWidth={1.5} style={{ color: "var(--text-muted)" }} aria-hidden="true" />
      <p className="text-[15px] font-medium" style={{ color: "var(--text-primary)" }}>
        Sve je pod kontrolom
      </p>
      <p className="text-[13px]" style={{ color: "var(--text-muted)" }}>
        Nema ničega hitnog za danas.
      </p>
    </div>
  );
}
