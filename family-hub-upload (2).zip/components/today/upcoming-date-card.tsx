import { Cake, Gift, Car, Heart, Calendar as CalendarIcon } from "lucide-react";
import type { ImportantDate, DateCategory } from "@/lib/supabase/types";

const CATEGORY_ICON: Record<DateCategory, typeof Cake> = {
  birthday: Cake,
  anniversary: Heart,
  vehicle: Car,
  health: Gift,
  general: CalendarIcon,
};

function daysUntilLabel(daysUntil: number) {
  if (daysUntil === 0) return "Danas";
  if (daysUntil === 1) return "Sutra";
  return `Za ${daysUntil} dana`;
}

interface UpcomingDateCardProps {
  date: ImportantDate;
  daysUntil: number;
}

// Visually distinct from action cards (purple "pro" tint vs. neutral) on
// purpose — this is informational, not something to check off, so it
// shouldn't compete with the actionable Today/overdue sections for the
// same visual weight.
export function UpcomingDateCard({ date, daysUntil }: UpcomingDateCardProps) {
  const Icon = CATEGORY_ICON[date.category ?? "general"];

  return (
    <div className="flex items-center gap-2.5 rounded-xl px-3.5 py-3" style={{ background: "var(--bg-pro)" }}>
      <Icon size={20} strokeWidth={1.75} style={{ color: "var(--text-pro)" }} aria-hidden="true" />
      <div className="min-w-0 flex-1">
        <p className="truncate text-[14px] font-medium" style={{ color: "var(--text-pro)" }}>
          {date.title}
        </p>
        <p className="text-[12px]" style={{ color: "var(--text-pro)" }}>
          {daysUntilLabel(daysUntil)}
        </p>
      </div>
    </div>
  );
}
