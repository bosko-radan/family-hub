import { Avatar, EveryoneAvatar } from "@/components/shared/avatar";
import type { CalendarEvent, HouseholdMember } from "@/lib/supabase/types";

interface EventCardProps {
  event: CalendarEvent;
  members: HouseholdMember[];
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("sr-RS", { hour: "2-digit", minute: "2-digit" });
}

export function EventCard({ event, members }: EventCardProps) {
  const assignedMember = members.find((m) => m.id === event.assigned_to);

  return (
    <div
      className="flex items-center gap-2.5 rounded-xl border-[0.5px] px-3.5 py-3"
      style={{ background: "var(--surface-2)", borderColor: "var(--border)" }}
    >
      <div className="w-11 shrink-0 text-[13px]" style={{ color: "var(--text-secondary)" }}>
        {formatTime(event.starts_at)}
      </div>
      <p className="min-w-0 flex-1 truncate text-[14px]" style={{ color: "var(--text-primary)" }}>
        {event.title}
      </p>
      {event.assigned_to_everyone ? (
        <EveryoneAvatar size="sm" />
      ) : assignedMember ? (
        <Avatar initial={assignedMember.display_name[0]} color={assignedMember.avatar_color} size="sm" />
      ) : null}
    </div>
  );
}
