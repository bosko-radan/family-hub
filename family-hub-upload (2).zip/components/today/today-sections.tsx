"use client";

import { useState } from "react";
import { AlertTriangle, Calendar as CalendarIcon, CheckSquare, PartyPopper } from "lucide-react";
import { TaskCard } from "@/components/today/task-card";
import { EventCard } from "@/components/today/event-card";
import { UpcomingDateCard } from "@/components/today/upcoming-date-card";
import { TodayEmptyState } from "@/components/today/today-empty-state";
import type { Task, CalendarEvent, ImportantDate, HouseholdMember } from "@/lib/supabase/types";

interface TodaySectionsProps {
  overdueTasks: Task[];
  todayEvents: CalendarEvent[];
  tasksToday: Task[];
  upcomingDates: ImportantDate[];
  members: HouseholdMember[];
}

// Caps the number of visible cards in the tasks-today section before
// collapsing the rest behind "show more" — per the edge case we designed
// for: more than ~5 items would push the hierarchy below the fold and
// make the screen feel cluttered rather than scannable at a glance.
const VISIBLE_TASKS_LIMIT = 3;

export function TodaySections({ overdueTasks, todayEvents, tasksToday, upcomingDates, members }: TodaySectionsProps) {
  const [tasksExpanded, setTasksExpanded] = useState(false);
  const [, setOpenTaskId] = useState<string | null>(null);

  const visibleTasks = tasksExpanded ? tasksToday : tasksToday.slice(0, VISIBLE_TASKS_LIMIT);
  const hiddenTasksCount = tasksToday.length - visibleTasks.length;

  const hasNothing =
    overdueTasks.length === 0 && todayEvents.length === 0 && tasksToday.length === 0 && upcomingDates.length === 0;

  function handleOpenTaskDetails(taskId: string) {
    // Detail modal is intentionally out of scope for this build pass —
    // wired here as a no-op placeholder so the tap target and intended
    // interaction exist now and a modal (intercepting route) can be
    // dropped in later without touching TaskCard's calling contract.
    setOpenTaskId(taskId);
  }

  if (hasNothing) {
    return <TodayEmptyState />;
  }

  return (
    <div className="flex flex-col gap-5 px-4 py-4">
      {overdueTasks.length > 0 && (
        <section>
          <SectionHeader icon={AlertTriangle} label="Zakasnelo" tone="danger" />
          <div className="flex flex-col gap-2">
            {overdueTasks.map((task) => (
              <TaskCard key={task.id} task={task} members={members} variant="overdue" onOpenDetails={handleOpenTaskDetails} />
            ))}
          </div>
        </section>
      )}

      {todayEvents.length > 0 && (
        <section>
          <SectionHeader icon={CalendarIcon} label="Danas" />
          <div className="flex flex-col gap-2">
            {todayEvents.map((event) => (
              <EventCard key={event.id} event={event} members={members} />
            ))}
          </div>
        </section>
      )}

      {tasksToday.length > 0 && (
        <section>
          <div className="mb-2 flex items-center justify-between">
            <SectionHeader icon={CheckSquare} label="Obaveze za danas" noMargin />
            <span className="text-[12px]" style={{ color: "var(--text-muted)" }}>
              {tasksToday.filter((t) => t.completed_at || t.last_completed_for_date).length} od {tasksToday.length}
            </span>
          </div>
          <div className="flex flex-col gap-2">
            {visibleTasks.map((task) => (
              <TaskCard key={task.id} task={task} members={members} onOpenDetails={handleOpenTaskDetails} />
            ))}
          </div>
          {hiddenTasksCount > 0 && (
            <button
              onClick={() => setTasksExpanded(true)}
              className="mt-2 w-full border-0 py-2 text-[13px]"
              style={{ background: "transparent", color: "var(--text-secondary)" }}
            >
              Prikaži još {hiddenTasksCount}
            </button>
          )}
        </section>
      )}

      {upcomingDates.length > 0 && (
        <section>
          <SectionHeader icon={PartyPopper} label="Uskoro" />
          <div className="flex flex-col gap-2">
            {upcomingDates.map((date) => (
              <UpcomingDateCard key={date.id} date={date} daysUntil={daysUntilFor(date)} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function daysUntilFor(date: ImportantDate): number {
  const now = new Date();
  const original = new Date(date.date);
  const candidate = new Date(now.getFullYear(), original.getMonth(), original.getDate());
  if (candidate < now) candidate.setFullYear(candidate.getFullYear() + 1);
  return Math.ceil((candidate.getTime() - now.getTime()) / 86_400_000);
}

function SectionHeader({
  icon: Icon,
  label,
  tone = "default",
  noMargin = false,
}: {
  icon: typeof AlertTriangle;
  label: string;
  tone?: "default" | "danger";
  noMargin?: boolean;
}) {
  const color = tone === "danger" ? "var(--text-danger)" : "var(--text-secondary)";
  return (
    <div className={`flex items-center gap-1.5 ${noMargin ? "" : "mb-2"}`}>
      <Icon size={16} strokeWidth={1.75} style={{ color }} aria-hidden="true" />
      <span className="text-[13px] font-medium" style={{ color }}>
        {label}
      </span>
    </div>
  );
}
