import type { LucideIcon } from "lucide-react";

interface ComingSoonProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

// Shared empty-state for modules not yet built (per the agreed build
// order: schema -> auth/layout -> Today -> everything else). Keeps every
// nav tab clickable and visually finished from day one instead of 404ing,
// so the shell feels complete even mid-build.
export function ComingSoon({ icon: Icon, title, description }: ComingSoonProps) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 px-6 py-24 text-center">
      <Icon size={32} strokeWidth={1.5} style={{ color: "var(--text-muted)" }} aria-hidden="true" />
      <p className="text-[15px] font-medium" style={{ color: "var(--text-primary)" }}>
        {title}
      </p>
      <p className="max-w-[240px] text-[13px]" style={{ color: "var(--text-muted)" }}>
        {description}
      </p>
    </div>
  );
}
