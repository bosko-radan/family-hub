"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Sun, ShoppingCart, ListChecks } from "lucide-react";
import { cn } from "@/lib/utils";

const TABS = [
  { href: "/today", label: "Danas", icon: Sun },
  { href: "/shopping", label: "Kupovina", icon: ShoppingCart },
  { href: "/tasks", label: "Obaveze", icon: ListChecks },
] as const;

// Fixed bottom tab bar — the primary navigation surface on mobile, where
// this app will be used almost exclusively (per the product decision).
// Five tabs is the practical ceiling at this width before icons crowd and
// labels truncate; "important dates" intentionally has no tab of its own
// since it surfaces through Today and Calendar instead of adding a sixth.
export function BottomNav() {
  const pathname = usePathname();

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-20 flex border-t-[0.5px] pb-[env(safe-area-inset-bottom)]"
      style={{ background: "var(--surface-1)", borderColor: "var(--border)" }}
      aria-label="Glavna navigacija"
    >
      {TABS.map(({ href, label, icon: Icon }) => {
        const active = pathname.startsWith(href);
        return (
          <Link
            key={href}
            href={href}
            className="flex flex-1 flex-col items-center gap-1 py-2"
            aria-current={active ? "page" : undefined}
          >
            <Icon
              size={20}
              strokeWidth={1.75}
              style={{ color: active ? "var(--text-accent)" : "var(--text-muted)" }}
              aria-hidden="true"
            />
            <span
              className={cn("text-[11px]", active ? "font-medium" : "font-normal")}
              style={{ color: active ? "var(--text-accent)" : "var(--text-muted)" }}
            >
              {label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
