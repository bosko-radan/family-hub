"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/components/shared/theme-provider";
import { Avatar } from "@/components/shared/avatar";
import type { AvatarColor } from "@/lib/supabase/types";

interface AppHeaderProps {
  title: string;
  memberInitial: string;
  memberColor: AvatarColor;
}

// Lives at the top of every authenticated screen. Theme toggle sits here
// rather than buried in settings because switching light/dark is frequent
// enough (morning vs. evening use) to deserve a one-tap, always-visible
// control — exactly the "minimal clicks" priority from the brief.
export function AppHeader({ title, memberInitial, memberColor }: AppHeaderProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <header
      className="flex items-center justify-between border-b-[0.5px] px-4 py-3.5"
      style={{ background: "var(--surface-0)", borderColor: "var(--border)" }}
    >
      <h1 className="text-[15px] font-medium" style={{ color: "var(--text-primary)" }}>
        {title}
      </h1>
      <div className="flex items-center gap-2.5">
        <button
          onClick={toggleTheme}
          aria-label={theme === "light" ? "Uključi tamnu temu" : "Uključi svetlu temu"}
          className="flex h-8 w-8 items-center justify-center rounded-full border-0"
          style={{ background: "transparent" }}
        >
          {theme === "light" ? (
            <Moon size={16} strokeWidth={1.75} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
          ) : (
            <Sun size={16} strokeWidth={1.75} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
          )}
        </button>
        <Avatar initial={memberInitial} color={memberColor} size="sm" />
      </div>
    </header>
  );
}
