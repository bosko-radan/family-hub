import { cn } from "@/lib/utils";
import type { AvatarColor } from "@/lib/supabase/types";

interface AvatarProps {
  initial: string;
  color: AvatarColor;
  size?: "sm" | "md";
  className?: string;
}

// One consistent avatar treatment used everywhere a household member is
// referenced — Today cards, calendar entries, shopping items. Colors map
// to CDS role tokens (not raw hex) so the same component looks correct in
// both light and dark mode without any extra logic at the call site.
export function Avatar({ initial, color, size = "sm", className }: AvatarProps) {
  return (
    <div
      className={cn(
        "flex shrink-0 items-center justify-center rounded-full font-medium",
        size === "sm" ? "h-6.5 w-6.5 text-[11px]" : "h-11 w-11 text-sm",
        color === "accent"
          ? "bg-[var(--bg-accent)] text-[var(--text-accent)]"
          : "bg-[var(--bg-pro)] text-[var(--text-pro)]",
        className
      )}
      aria-hidden="true"
    >
      {initial}
    </div>
  );
}

// Renders "everyone" assignment as a paired mini-avatar instead of a single
// initial, so "either of us" reads visually distinct from "just one of us"
// at a glance rather than requiring the user to read a label.
export function EveryoneAvatar({ size = "sm" }: { size?: "sm" | "md" }) {
  return (
    <div className="flex shrink-0 items-center -space-x-1.5" aria-hidden="true">
      <Avatar initial="J" color="accent" size={size} className="ring-2 ring-[var(--surface-2)]" />
      <Avatar initial="M" color="pro" size={size} className="ring-2 ring-[var(--surface-2)]" />
    </div>
  );
}
