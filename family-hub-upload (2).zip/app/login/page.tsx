"use client";

import { useActionState } from "react";
import Link from "next/link";
import { Home } from "lucide-react";
import { loginAction, type AuthActionResult } from "@/app/login/actions";

const initialState: AuthActionResult = { error: null };

export default function LoginPage() {
  const [state, formAction, pending] = useActionState(loginAction, initialState);

  return (
    <div className="flex min-h-screen items-center justify-center px-4" style={{ background: "var(--surface-0)" }}>
      <div
        className="w-full max-w-[360px] rounded-3xl border-[0.5px] px-6 py-10"
        style={{ background: "var(--surface-1)", borderColor: "var(--border)" }}
      >
        <div className="flex flex-col items-center">
          <div
            className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl"
            style={{ background: "var(--bg-accent)" }}
          >
            <Home size={24} strokeWidth={1.75} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
          </div>
          <h1 className="mb-1 text-xl font-medium" style={{ color: "var(--text-primary)" }}>
            Family hub
          </h1>
          <p className="mb-8 text-[13px]" style={{ color: "var(--text-muted)" }}>
            Prijavi se da nastaviš
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-2.5">
          <div>
            <label htmlFor="email" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Email
            </label>
            <input id="email" name="email" type="email" placeholder="ti@example.com" required autoComplete="email" />
          </div>
          <div>
            <label htmlFor="password" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Lozinka
            </label>
            <input
              id="password"
              name="password"
              type="password"
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />
          </div>

          {state.error && (
            <p className="text-[13px]" style={{ color: "var(--text-danger)" }} role="alert">
              {state.error}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="mt-2 h-10 border-0 font-medium"
            style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
          >
            {pending ? "Prijavljujem…" : "Prijavi se"}
          </button>

          <Link
            href="/login/reset-password"
            className="mt-1 text-center text-[13px]"
            style={{ color: "var(--text-secondary)" }}
          >
            Zaboravljena lozinka?
          </Link>
        </form>

        <p className="mt-6 text-center text-[13px]" style={{ color: "var(--text-muted)" }}>
          Pozvani ste u domaćinstvo?{" "}
          <Link href="/signup" style={{ color: "var(--text-accent)" }}>
            Registruj se sa kodom
          </Link>
        </p>
      </div>
    </div>
  );
}
