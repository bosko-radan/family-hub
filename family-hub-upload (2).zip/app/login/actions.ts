"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export interface AuthActionResult {
  error: string | null;
}

// Server action backing the login form. Returns a plain error string
// instead of throwing, so the client component can render it inline next
// to the form without an error boundary — login failures are an expected,
// frequent outcome (typo'd password), not an exceptional one.
export async function loginAction(
  _prevState: AuthActionResult,
  formData: FormData
): Promise<AuthActionResult> {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  if (!email || !password) {
    return { error: "Unesi email i lozinku." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) {
    return { error: "Pogrešan email ili lozinka." };
  }

  redirect("/today");
}
