"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { AuthActionResult } from "@/app/login/actions";

// Signup requires a valid invite code rather than an open form — there is
// intentionally no path to creating a brand-new household from this page.
// That keeps "who can join" a deliberate, one-time action (see
// createHouseholdAction for the only way a household comes into existence)
// instead of something a stray link or guessed URL could trigger.
export async function signupWithInviteAction(
  _prevState: AuthActionResult,
  formData: FormData
): Promise<AuthActionResult> {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;
  const displayName = formData.get("displayName") as string;
  const inviteCode = (formData.get("inviteCode") as string)?.trim().toUpperCase();

  if (!email || !password || !displayName || !inviteCode) {
    return { error: "Popuni sva polja." };
  }

  const supabase = await createClient();

  const { error: signUpError } = await supabase.auth.signUp({ email, password });
  if (signUpError) {
    return { error: signUpError.message === "User already registered"
      ? "Već postoji nalog sa ovim emailom."
      : "Nešto je pošlo po zlu pri registraciji." };
  }

  // The auth row now exists, so RLS-bound calls below run as this user.
  // redeem_household_invite validates expiry/single-use atomically and
  // creates the household_members row in one transaction — see migration
  // 0003 for why this can't be a plain client-side insert.
  const { error: redeemError } = await supabase.rpc("redeem_household_invite", {
    invite_code: inviteCode,
    member_display_name: displayName,
    member_avatar_color: "pro",
  });

  if (redeemError) {
    return { error: "Pozivni kod nije važeći ili je istekao." };
  }

  redirect("/today");
}
