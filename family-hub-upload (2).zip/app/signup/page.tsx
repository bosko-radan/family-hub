"use client";

import { useActionState } from "react";
import Link from "next/link";
import { Home } from "lucide-react";
import { signupWithInviteAction } from "@/app/signup/actions";
import type { AuthActionResult } from "@/app/login/actions";

const initialState: AuthActionResult = { error: null };

export default function SignupPage() {
  const [state, formAction, pending] = useActionState(signupWithInviteAction, initialState);

  return (
    <div className="flex min-h-screen items-center justify-center px-4" style={{ background: "var(--surface-0)" }}>
      <div
        className="w-full max-w-[360px] rounded-3xl border-[0.5px] px-6 py-10"
        style={{ background: "var(--surface-1)", borderColor: "var(--border)" }}
      >
        <div className="flex flex-col items-center">
          <div
            className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl"
            style={{ background: "var(--bg-pro)" }}
          >
            <Home size={24} strokeWidth={1.75} style={{ color: "var(--text-pro)" }} aria-hidden="true" />
          </div>
          <h1 className="mb-1 text-xl font-medium" style={{ color: "var(--text-primary)" }}>
            Pridruži se domaćinstvu
          </h1>
          <p className="mb-8 text-center text-[13px]" style={{ color: "var(--text-muted)" }}>
            Unesi pozivni kod koji si dobio/la
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-2.5">
          <div>
            <label htmlFor="inviteCode" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Pozivni kod
            </label>
            <input
              id="inviteCode"
              name="inviteCode"
              type="text"
              placeholder="ABC123"
              required
              className="uppercase tracking-wide"
              maxLength={8}
            />
          </div>
          <div>
            <label htmlFor="displayName" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Tvoje ime
            </label>
            <input id="displayName" name="displayName" type="text" placeholder="Marija" required />
          </div>
          <div>
            <label htmlFor="email" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Email
            </label>
            <input id="email" name="email" type="email" placeholder="ti@example.com" required autoComplete="email" />
          </div>
          <div>
            <label htmlFor="password" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Lozinka
            </label>
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Najmanje 8 karaktera"
              required
              minLength={8}
              autoComplete="new-password"
            />
          </div>

          {state.error && (
            <p className="text-[13px]" style={{ color: "var(--text-danger)" }} role="alert">
              {state.error}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="mt-2 h-10 border-0 font-medium"
            style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
          >
            {pending ? "Registrujem…" : "Pridruži se"}
          </button>
        </form>

        <p className="mt-6 text-center text-[13px]" style={{ color: "var(--text-muted)" }}>
          Već imaš nalog?{" "}
          <Link href="/login" style={{ color: "var(--text-accent)" }}>
            Prijavi se
          </Link>
        </p>
      </div>
    </div>
  );
}
