"use server";

import { createClient } from "@/lib/supabase/server";

export interface SetupActionResult {
  error: string | null;
  inviteCode: string | null;
}

function generateInviteCode(): string {
  // Excludes visually ambiguous characters (0/O, 1/I) since this code gets
  // read off a phone screen and typed or dictated over a call.
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}

// This is the ONLY path that creates a new household — intentionally
// separate from /signup, which only ever joins an existing one via invite
// code. Keeping these as two distinct flows (rather than one form with a
// "create or join" toggle) means a household can never be created by
// accident through a confused signup attempt.
export async function createHouseholdAction(
  _prevState: SetupActionResult,
  formData: FormData
): Promise<SetupActionResult> {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;
  const displayName = formData.get("displayName") as string;

  if (!email || !password || !displayName) {
    return { error: "Popuni sva polja.", inviteCode: null };
  }

  const supabase = await createClient();

  const { data: signUpData, error: signUpError } = await supabase.auth.signUp({ email, password });
  if (signUpError || !signUpData.user) {
    return {
      error: signUpError?.message === "User already registered"
        ? "Već postoji nalog sa ovim emailom."
        : "Nešto je pošlo po zlu pri registraciji.",
      inviteCode: null,
    };
  }

  const { data: household, error: householdError } = await supabase
    .from("households")
    .insert({ name: `${displayName}'s home` })
    .select()
    .single();

  if (householdError || !household) {
    return { error: "Nije moguće kreirati domaćinstvo. Pokušaj ponovo.", inviteCode: null };
  }

  const { data: member, error: memberError } = await supabase
    .from("household_members")
    .insert({
      household_id: household.id,
      user_id: signUpData.user.id,
      display_name: displayName,
      avatar_color: "accent",
    })
    .select()
    .single();

  if (memberError || !member) {
    return { error: "Nije moguće kreirati profil. Pokušaj ponovo.", inviteCode: null };
  }

  const code = generateInviteCode();
  await supabase.from("household_invites").insert({
    household_id: household.id,
    code,
    created_by: member.id,
  });

  // Returned (not redirected) on purpose — this code is shown exactly once,
  // right after creation, since there's no other screen in the MVP that
  // surfaces it later. The person must copy/share it now.
  return { error: null, inviteCode: code };
}
