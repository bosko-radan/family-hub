"use client";

import { useActionState } from "react";
import Link from "next/link";
import { Home, Copy, Check } from "lucide-react";
import { useState } from "react";
import { createHouseholdAction, type SetupActionResult } from "@/app/setup/actions";

const initialState: SetupActionResult = { error: null, inviteCode: null };

// Reached only by whoever sets the app up for the first time — not linked
// from the login page, since this is a one-time action rather than part
// of the everyday auth flow. Share this URL with yourself once; afterwards
// every future signup goes through /signup with the generated invite code.
export default function SetupPage() {
  const [state, formAction, pending] = useActionState(createHouseholdAction, initialState);
  const [copied, setCopied] = useState(false);

  function handleCopy() {
    if (!state.inviteCode) return;
    navigator.clipboard.writeText(state.inviteCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  // Success screen: the invite code is shown exactly once, right after
  // creation — there's no other place in the MVP that surfaces it again,
  // so this screen's only job is making sure it gets copied/shared before
  // moving on.
  if (state.inviteCode) {
    return (
      <div className="flex min-h-screen items-center justify-center px-4" style={{ background: "var(--surface-0)" }}>
        <div
          className="w-full max-w-[360px] rounded-3xl border-[0.5px] px-6 py-10 text-center"
          style={{ background: "var(--surface-1)", borderColor: "var(--border)" }}
        >
          <div
            className="mx-auto mb-5 flex h-12 w-12 items-center justify-center rounded-2xl"
            style={{ background: "var(--bg-accent)" }}
          >
            <Check size={24} strokeWidth={1.75} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
          </div>
          <h1 className="mb-1 text-xl font-medium" style={{ color: "var(--text-primary)" }}>
            Domaćinstvo je spremno
          </h1>
          <p className="mb-6 text-[13px]" style={{ color: "var(--text-muted)" }}>
            Pošalji ovaj kod partneru da se pridruži
          </p>

          <button
            onClick={handleCopy}
            className="mb-6 flex w-full items-center justify-center gap-2 border-0 py-4"
            style={{ background: "var(--bg-accent)" }}
          >
            <span className="text-2xl font-medium tracking-[0.15em]" style={{ color: "var(--text-accent)" }}>
              {state.inviteCode}
            </span>
            {copied ? (
              <Check size={18} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
            ) : (
              <Copy size={18} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
            )}
          </button>

          <p className="mb-6 text-[12px]" style={{ color: "var(--text-muted)" }}>
            Kod važi 7 dana. Partner ga unosi na strani za registraciju.
          </p>

          <Link
            href="/today"
            className="flex h-10 w-full items-center justify-center font-medium"
            style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
          >
            Idi na Family hub
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="flex min-h-screen items-center justify-center px-4" style={{ background: "var(--surface-0)" }}>
      <div
        className="w-full max-w-[360px] rounded-3xl border-[0.5px] px-6 py-10"
        style={{ background: "var(--surface-1)", borderColor: "var(--border)" }}
      >
        <div className="flex flex-col items-center">
          <div
            className="mb-5 flex h-12 w-12 items-center justify-center rounded-2xl"
            style={{ background: "var(--bg-accent)" }}
          >
            <Home size={24} strokeWidth={1.75} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
          </div>
          <h1 className="mb-1 text-xl font-medium" style={{ color: "var(--text-primary)" }}>
            Napravi svoje domaćinstvo
          </h1>
          <p className="mb-8 text-center text-[13px]" style={{ color: "var(--text-muted)" }}>
            Posle ovoga ćeš dobiti kod da pozoveš partnera
          </p>
        </div>

        <form action={formAction} className="flex flex-col gap-2.5">
          <div>
            <label htmlFor="displayName" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Tvoje ime
            </label>
            <input id="displayName" name="displayName" type="text" placeholder="Jovan" required />
          </div>
          <div>
            <label htmlFor="email" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Email
            </label>
            <input id="email" name="email" type="email" placeholder="ti@example.com" required autoComplete="email" />
          </div>
          <div>
            <label htmlFor="password" className="mb-1.5 block text-[13px]" style={{ color: "var(--text-secondary)" }}>
              Lozinka
            </label>
            <input
              id="password"
              name="password"
              type="password"
              placeholder="Najmanje 8 karaktera"
              required
              minLength={8}
              autoComplete="new-password"
            />
          </div>

          {state.error && (
            <p className="text-[13px]" style={{ color: "var(--text-danger)" }} role="alert">
              {state.error}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="mt-2 h-10 border-0 font-medium"
            style={{ background: "var(--fill-primary)", color: "var(--on-primary)" }}
          >
            {pending ? "Kreiram…" : "Napravi domaćinstvo"}
          </button>
        </form>
      </div>
    </div>
  );
}
