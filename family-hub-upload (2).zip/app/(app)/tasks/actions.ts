"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMember } from "@/lib/get-current-member";

export async function createTaskAction(formData: FormData) {
  const title = (formData.get("title") as string)?.trim();
  const dueDate = formData.get("dueDate") as string;
  const recurrence = formData.get("recurrence") as string; // "none" | "daily" | "weekly" | "monthly"
  const assignment = formData.get("assignment") as string; // "me" | "partner" | "everyone" | "unassigned"

  if (!title || !dueDate) return;

  const member = await getCurrentMember();
  if (!member) return;

  const isRecurring = recurrence !== "none";

  let assignedTo: string | null = null;
  let assignedToEveryone = false;

  const supabase = await createClient();

  if (assignment === "everyone") {
    assignedToEveryone = true;
  } else if (assignment === "me") {
    assignedTo = member.id;
  } else if (assignment === "partner") {
    const { data: members } = await supabase
      .from("household_members")
      .select("id")
      .neq("id", member.id)
      .limit(1);
    assignedTo = members?.[0]?.id ?? null;
  }

  await supabase.from("tasks").insert({
    household_id: member.household_id,
    title,
    due_date: dueDate,
    is_recurring: isRecurring,
    recurrence_rule: isRecurring ? recurrence : null,
    assigned_to: assignedTo,
    assigned_to_everyone: assignedToEveryone,
    created_by: member.id,
  });

  revalidatePath("/tasks");
  revalidatePath("/today");
}
