import { createClient } from "@/lib/supabase/server";
import { getCurrentMember } from "@/lib/get-current-member";
import { getHouseholdMembers } from "@/lib/get-household-members";
import { TasksList } from "@/components/tasks/tasks-list";
import { NewTaskSheet } from "@/components/tasks/new-task-sheet";

export default async function TasksPage() {
  const supabase = await createClient();
  const [{ data: tasks }, currentMember, members] = await Promise.all([
    supabase.from("tasks").select("*").order("due_date", { ascending: true }),
    getCurrentMember(),
    getHouseholdMembers(),
  ]);

  if (!currentMember) return null;
  const partner = members.find((m) => m.id !== currentMember.id) ?? null;

  return (
    <div className="flex flex-col gap-1 px-4 py-4">
      <h1 className="mb-2 text-[18px] font-medium" style={{ color: "var(--text-primary)" }}>
        Obaveze
      </h1>
      <TasksList tasks={tasks ?? []} members={members} />
      <NewTaskSheet currentMember={currentMember} partner={partner} />
    </div>
  );
}
