"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMember } from "@/lib/get-current-member";

export async function addShoppingItemAction(listId: string, formData: FormData) {
  const name = (formData.get("name") as string)?.trim();
  const quantity = (formData.get("quantity") as string)?.trim() || null;
  if (!name) return;

  const member = await getCurrentMember();
  const supabase = await createClient();

  // New items go to the top (sort_order shifted below the current min) —
  // easiest to type a new item and see it land where you're already
  // looking, rather than scrolling down to find what you just added.
  const { data: existing } = await supabase
    .from("shopping_items")
    .select("sort_order")
    .eq("list_id", listId)
    .order("sort_order", { ascending: true })
    .limit(1);

  const minOrder = existing?.[0]?.sort_order ?? 0;

  await supabase.from("shopping_items").insert({
    list_id: listId,
    name,
    quantity,
    sort_order: minOrder - 1,
    added_by: member?.id ?? null,
  });

  revalidatePath(`/shopping/${listId}`);
}

export async function toggleShoppingItemAction(itemId: string, listId: string) {
  const supabase = await createClient();
  const { data: item } = await supabase.from("shopping_items").select("checked_at").eq("id", itemId).single();
  if (!item) return;

  await supabase
    .from("shopping_items")
    .update({ checked_at: item.checked_at ? null : new Date().toISOString() })
    .eq("id", itemId);

  revalidatePath(`/shopping/${listId}`);
}

export async function deleteShoppingItemAction(itemId: string, listId: string) {
  const supabase = await createClient();
  await supabase.from("shopping_items").delete().eq("id", itemId);
  revalidatePath(`/shopping/${listId}`);
}

// Persists a new manual order after a drag-to-reorder. Receives the items
// in their new visual order and writes sequential sort_order values —
// simplest correct approach for a handful of items; no need for the
// fractional-index scheme a larger list might want.
export async function reorderShoppingItemsAction(listId: string, orderedItemIds: string[]) {
  const supabase = await createClient();
  await Promise.all(
    orderedItemIds.map((id, index) =>
      supabase.from("shopping_items").update({ sort_order: index }).eq("id", id)
    )
  );
  revalidatePath(`/shopping/${listId}`);
}
