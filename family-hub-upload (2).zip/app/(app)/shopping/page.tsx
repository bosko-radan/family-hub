import Link from "next/link";
import { ShoppingCart, ChevronRight } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { NewListForm } from "@/components/shopping/new-list-form";

// Server component: fetches lists and all shopping items in two simple
// queries, then counts unchecked items per list in memory. A relational
// select (lists with nested items) would need real Relationships entries
// in the Database type to type-check — not worth wiring up for two flat
// queries against a small table.
export default async function ShoppingPage() {
  const supabase = await createClient();
  const [{ data: lists }, { data: items }] = await Promise.all([
    supabase.from("shopping_lists").select("*").order("created_at", { ascending: true }),
    supabase.from("shopping_items").select("list_id, checked_at"),
  ]);

  const remainingCountByList = new Map<string, number>();
  for (const item of items ?? []) {
    if (!item.checked_at) {
      remainingCountByList.set(item.list_id, (remainingCountByList.get(item.list_id) ?? 0) + 1);
    }
  }

  return (
    <div className="flex flex-col gap-3 px-4 py-4">
      <h1 className="text-[18px] font-medium" style={{ color: "var(--text-primary)" }}>
        Liste
      </h1>

      {lists?.map((list) => (
        <Link
          key={list.id}
          href={`/shopping/${list.id}`}
          className="flex items-center gap-2.5 rounded-xl border-[0.5px] px-3.5 py-3"
          style={{ background: "var(--surface-2)", borderColor: "var(--border)" }}
        >
          <ShoppingCart size={18} strokeWidth={1.75} style={{ color: "var(--text-accent)" }} aria-hidden="true" />
          <span className="flex-1 text-[14px]" style={{ color: "var(--text-primary)" }}>
            {list.name}
          </span>
          <span className="text-[12px]" style={{ color: "var(--text-muted)" }}>
            {remainingCountByList.get(list.id) ?? 0}
          </span>
          <ChevronRight size={16} style={{ color: "var(--text-muted)" }} aria-hidden="true" />
        </Link>
      ))}

      <NewListForm />
    </div>
  );
}
