"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { getCurrentMember } from "@/lib/get-current-member";

export async function createShoppingListAction(formData: FormData) {
  const name = (formData.get("name") as string)?.trim();
  if (!name) return;

  const member = await getCurrentMember();
  if (!member) return;

  const supabase = await createClient();
  const { data } = await supabase
    .from("shopping_lists")
    .insert({ household_id: member.household_id, name })
    .select()
    .single();

  revalidatePath("/shopping");
  if (data) redirect(`/shopping/${data.id}`);
}

export async function deleteShoppingListAction(listId: string) {
  const supabase = await createClient();
  await supabase.from("shopping_lists").delete().eq("id", listId);
  revalidatePath("/shopping");
}
