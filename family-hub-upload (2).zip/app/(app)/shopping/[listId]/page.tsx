import Link from "next/link";
import { notFound } from "next/navigation";
import { ChevronLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { SortableShoppingList } from "@/components/shopping/sortable-shopping-list";
import { AddItemForm } from "@/components/shopping/add-item-form";

export default async function ShoppingListPage({ params }: { params: Promise<{ listId: string }> }) {
  const { listId } = await params;
  const supabase = await createClient();

  const [{ data: list }, { data: items }] = await Promise.all([
    supabase.from("shopping_lists").select("*").eq("id", listId).single(),
    supabase.from("shopping_items").select("*").eq("list_id", listId).order("sort_order", { ascending: true }),
  ]);

  if (!list) notFound();

  return (
    <div className="flex flex-col gap-1 px-4 py-4">
      <div className="mb-1 flex items-center gap-2">
        <Link href="/shopping" aria-label="Nazad na liste" className="flex h-8 w-8 items-center justify-center">
          <ChevronLeft size={18} style={{ color: "var(--text-secondary)" }} aria-hidden="true" />
        </Link>
        <h1 className="text-[18px] font-medium" style={{ color: "var(--text-primary)" }}>
          {list.name}
        </h1>
      </div>

      <SortableShoppingList items={items ?? []} listId={listId} />
      <AddItemForm listId={listId} />
    </div>
  );
}
