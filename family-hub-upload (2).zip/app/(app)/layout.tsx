import { redirect } from "next/navigation";
import { AppHeader } from "@/components/shared/app-header";
import { BottomNav } from "@/components/shared/bottom-nav";
import { getCurrentMember } from "@/lib/get-current-member";

// Shared shell for every authenticated screen. The actual auth gate lives
// in middleware.ts (it redirects before this even renders), so the null
// check here is a defensive fallback, not the primary guard — two layers
// because a middleware matcher typo should never expose a blank app shell.
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const member = await getCurrentMember();

  if (!member) {
    redirect("/login");
  }

  return (
    <div className="flex min-h-screen flex-col" style={{ background: "var(--surface-0)" }}>
      <AppHeader title="Family hub" memberInitial={member.display_name[0]} memberColor={member.avatar_color} />
      <main className="flex-1 overflow-y-auto pb-20">{children}</main>
      <BottomNav />
    </div>
  );
}
