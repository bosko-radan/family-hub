import { getTodayData } from "@/lib/today/get-today-data";
import { getHouseholdMembers } from "@/lib/get-household-members";
import { TodaySections } from "@/components/today/today-sections";
import { QuickAddButton } from "@/components/today/quick-add-button";

// Server component: data is fetched before the page ever reaches the
// client, so there is no loading spinner on first paint — per the
// architectural decision to favor server-side fetch for this screen. The
// interactive pieces (checkbox toggles, quick-add sheet) are isolated into
// their own client components rather than making this whole tree client-
// rendered.
export default async function TodayPage() {
  const [todayData, members] = await Promise.all([getTodayData(), getHouseholdMembers()]);

  return (
    <>
      <TodaySections
        overdueTasks={todayData.overdueTasks}
        todayEvents={todayData.todayEvents}
        tasksToday={todayData.tasksToday}
        upcomingDates={todayData.upcomingDates}
        members={members}
      />
      <QuickAddButton />
    </>
  );
}
