"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

// Toggles a task's completion. For recurring tasks, "done" is tracked
// per-cycle via last_completed_for_date rather than completed_at, so
// checking off "water the plants" today doesn't permanently complete every
// future occurrence — only today's instance. One-off tasks use completed_
// at directly since there's no future occurrence to preserve.
export async function toggleTaskCompletionAction(taskId: string, dueDate: string | null) {
  const supabase = await createClient();

  const { data: task } = await supabase.from("tasks").select("*").eq("id", taskId).single();
  if (!task) return;

  const today = new Date().toISOString().slice(0, 10);

  if (task.is_recurring) {
    const isCurrentlyDoneForToday = task.last_completed_for_date === today;
    await supabase
      .from("tasks")
      .update({ last_completed_for_date: isCurrentlyDoneForToday ? null : today })
      .eq("id", taskId);
  } else {
    const isCurrentlyDone = !!task.completed_at;
    await supabase
      .from("tasks")
      .update({ completed_at: isCurrentlyDone ? null : new Date().toISOString() })
      .eq("id", taskId);
  }

  // Today view is server-rendered, so the cache needs an explicit nudge to
  // reflect the change — there's no client-side store to update instead.
  revalidatePath("/today");
}
