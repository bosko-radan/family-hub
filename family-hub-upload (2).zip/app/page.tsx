import { redirect } from "next/navigation";

// Root URL has no content of its own — middleware already decides between
// /today (authenticated) and /login (not), so this just closes the gap for
// a direct hit on "/" before middleware's redirect logic re-runs here.
export default function RootPage() {
  redirect("/today");
}
