-- ============================================================================
-- FAMILY HUB — important_date -> calendar_event sync
-- ============================================================================
-- Why this exists:
-- The Today view needs a single source for "what happens today" (calendar_
-- events) and a separate source for "what's coming up" (important_dates),
-- without showing the same thing twice. Rather than have the frontend
-- de-duplicate two lists on every render, we generate the linked event once,
-- in the database, whenever an important date is created or edited with a
-- specific time component carried in its title metadata via the optional
-- event_time column. Plain "no time" dates (e.g. "car registration due")
-- never create an event — they only ever appear in the "upcoming" section.
-- ============================================================================

alter table important_dates
  add column event_time time,
  add column event_duration_minutes integer default 60;

create or replace function sync_important_date_event()
returns trigger as $$
begin
  -- Remove any previously generated event for this date before re-creating,
  -- so edits (time changed, time removed) don't leave orphaned events.
  delete from calendar_events where source_important_date_id = coalesce(new.id, old.id);

  if (tg_op = 'DELETE') then
    return old;
  end if;

  if new.event_time is not null then
    insert into calendar_events (
      household_id, title, starts_at, ends_at,
      source_important_date_id, created_by
    )
    values (
      new.household_id,
      new.title,
      (new.date + new.event_time) at time zone 'UTC',
      (new.date + new.event_time + (new.event_duration_minutes || ' minutes')::interval) at time zone 'UTC',
      new.id,
      new.created_by
    );
  end if;

  return new;
end;
$$ language plpgsql security definer;

create trigger trg_sync_important_date_event
  after insert or update or delete on important_dates
  for each row execute function sync_important_date_event();
