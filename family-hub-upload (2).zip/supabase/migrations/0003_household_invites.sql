-- ============================================================================
-- FAMILY HUB — household invites
-- ============================================================================
-- A short-lived, single-use code that lets a second person join an existing
-- household at signup. Codes expire and are consumed atomically so two
-- concurrent signups can't both redeem the same code (see redeem function).
-- ============================================================================

create table household_invites (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  code text not null unique,
  created_by uuid references household_members(id) on delete set null,
  expires_at timestamptz not null default (now() + interval '7 days'),
  redeemed_at timestamptz,
  redeemed_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now()
);

create index idx_household_invites_code on household_invites(code) where redeemed_at is null;

alter table household_invites enable row level security;

create policy "view own household invites" on household_invites
  for select using (household_id in (select my_household_ids()));

create policy "create invites for own household" on household_invites
  for insert with check (household_id in (select my_household_ids()));

-- Redeeming a code happens BEFORE the caller is a household member (that's
-- the whole point), so it can't go through the normal RLS-scoped insert
-- path. Instead, a security-definer function does the lookup, validation,
-- and member creation atomically, bypassing RLS only for this one
-- controlled operation. The function checks expiry and single-use itself
-- rather than relying on the caller to behave.
create or replace function redeem_household_invite(
  invite_code text,
  member_display_name text,
  member_avatar_color text
)
returns uuid as $$
declare
  v_invite household_invites;
  v_new_member_id uuid;
begin
  select * into v_invite
  from household_invites
  where code = invite_code
    and redeemed_at is null
    and expires_at > now()
  for update;

  if v_invite is null then
    raise exception 'invalid_or_expired_invite';
  end if;

  insert into household_members (household_id, user_id, display_name, avatar_color)
  values (v_invite.household_id, auth.uid(), member_display_name, member_avatar_color)
  returning id into v_new_member_id;

  update household_invites
  set redeemed_at = now(), redeemed_by = v_new_member_id
  where id = v_invite.id;

  return v_invite.household_id;
end;
$$ language plpgsql security definer;
