-- ============================================================================
-- FAMILY HUB — Initial schema
-- ============================================================================
-- Design notes:
-- - Every domain table carries household_id so RLS can scope by household.
-- - Recurring items store a rule (not pre-generated rows) and are expanded
--   at query time. Keeps the table small and rules editable after creation.
-- - important_dates is the source of truth for "this date matters every
--   year"; calendar_events is the source of truth for "something happens
--   at this time". A date with a specific time auto-creates a linked event
--   (see trigger below) so the Today view never has to de-duplicate by hand.
-- ============================================================================

create extension if not exists "uuid-ossp";

-- ----------------------------------------------------------------------------
-- households & members
-- ----------------------------------------------------------------------------

create table households (
  id uuid primary key default uuid_generate_v4(),
  name text not null default 'Our home',
  created_at timestamptz not null default now()
);

create table household_members (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  display_name text not null,
  -- avatar_color picks a CDS role token name ('accent' | 'pro') so the
  -- frontend can render a consistent, theme-aware avatar without storing
  -- a raw hex value that would break in dark mode.
  avatar_color text not null default 'accent' check (avatar_color in ('accent', 'pro')),
  created_at timestamptz not null default now(),
  unique (household_id, user_id)
);

create index idx_household_members_user on household_members(user_id);

-- ----------------------------------------------------------------------------
-- tasks (merged to-do + household chores, one-off or recurring)
-- ----------------------------------------------------------------------------

create table tasks (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  title text not null,
  notes text,
  due_date date,
  is_recurring boolean not null default false,
  -- Simple recurrence rule, e.g. 'daily', 'weekly:mon,thu', 'monthly:1'.
  -- Parsed in application code rather than a separate rules table —
  -- two users don't need relational queries over recurrence patterns,
  -- just a string the expansion function can read.
  recurrence_rule text,
  -- assigned_to is nullable on purpose: null + assigned_to_everyone=false
  -- means "unassigned", a specific id means "this person", and
  -- assigned_to_everyone=true means "either of us" (assigned_to is ignored
  -- in that case, enforced by the check constraint below). Keeping this as
  -- a boolean flag rather than a third magic UUID value keeps the foreign
  -- key meaningful and avoids CASE-based parsing in every query.
  assigned_to uuid references household_members(id) on delete set null,
  assigned_to_everyone boolean not null default false,
  completed_at timestamptz,
  -- For recurring tasks, completion is tracked per cycle via this date,
  -- so "done this week" doesn't mark all future occurrences done too.
  last_completed_for_date date,
  created_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint chk_tasks_assignment_exclusive
    check (not (assigned_to is not null and assigned_to_everyone))
);
create index idx_tasks_household on tasks(household_id);
create index idx_tasks_due_date on tasks(household_id, due_date) where completed_at is null;

-- ----------------------------------------------------------------------------
-- calendar events
-- ----------------------------------------------------------------------------

create table calendar_events (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  title text not null,
  starts_at timestamptz not null,
  ends_at timestamptz,
  reminder_minutes_before integer,
  assigned_to uuid references household_members(id) on delete set null,
  assigned_to_everyone boolean not null default false,
  -- Set when this event was auto-generated from an important_date, so we
  -- can update/delete it in lockstep if the source date changes.
  source_important_date_id uuid,
  created_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint chk_events_assignment_exclusive
    check (not (assigned_to is not null and assigned_to_everyone))
);

create index idx_events_household_date on calendar_events(household_id, starts_at);

-- ----------------------------------------------------------------------------
-- important dates (birthdays, anniversaries, recurring annual reminders)
-- ----------------------------------------------------------------------------

create table important_dates (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  title text not null,
  date date not null,
  recurrence text not null default 'yearly' check (recurrence in ('yearly', 'none')),
  remind_days_before integer not null default 3,
  category text default 'general' check (category in ('birthday', 'anniversary', 'vehicle', 'health', 'general')),
  created_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table calendar_events
  add constraint fk_source_important_date
  foreign key (source_important_date_id) references important_dates(id) on delete cascade;

create index idx_important_dates_household on important_dates(household_id);

-- ----------------------------------------------------------------------------
-- shopping lists & items
-- ----------------------------------------------------------------------------

create table shopping_lists (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  name text not null default 'Shopping list',
  created_at timestamptz not null default now()
);

create table shopping_items (
  id uuid primary key default uuid_generate_v4(),
  list_id uuid not null references shopping_lists(id) on delete cascade,
  name text not null,
  quantity text,
  checked_at timestamptz,
  -- Drag-to-reorder support without renumbering every row on each move.
  sort_order numeric not null default 0,
  added_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now()
);

create index idx_shopping_items_list on shopping_items(list_id, sort_order);

-- ----------------------------------------------------------------------------
-- quick notes
-- ----------------------------------------------------------------------------

create table notes (
  id uuid primary key default uuid_generate_v4(),
  household_id uuid not null references households(id) on delete cascade,
  content text not null,
  pinned boolean not null default false,
  created_by uuid references household_members(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index idx_notes_household on notes(household_id, pinned desc, updated_at desc);

-- ----------------------------------------------------------------------------
-- web push subscriptions (one browser/device per row)
-- ----------------------------------------------------------------------------

create table push_subscriptions (
  id uuid primary key default uuid_generate_v4(),
  household_member_id uuid not null references household_members(id) on delete cascade,
  endpoint text not null unique,
  p256dh_key text not null,
  auth_key text not null,
  created_at timestamptz not null default now()
);

create index idx_push_subscriptions_member on push_subscriptions(household_member_id);

-- ============================================================================
-- updated_at maintenance
-- ============================================================================

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger trg_notes_updated_at
  before update on notes
  for each row execute function set_updated_at();

-- ============================================================================
-- Row Level Security
-- ============================================================================
-- Every policy resolves through household_members so a user only ever sees
-- rows belonging to a household they are a member of. This is enforced at
-- the database layer, independent of any frontend bug.

alter table households enable row level security;
alter table household_members enable row level security;
alter table tasks enable row level security;
alter table calendar_events enable row level security;
alter table important_dates enable row level security;
alter table shopping_lists enable row level security;
alter table shopping_items enable row level security;
alter table notes enable row level security;
alter table push_subscriptions enable row level security;

-- Helper: households the current user belongs to. STABLE + SQL so Postgres
-- can inline/cache it within a query plan instead of re-running per row.
create or replace function my_household_ids()
returns setof uuid as $$
  select household_id from household_members where user_id = auth.uid();
$$ language sql stable;

create policy "select own household" on households
  for select using (id in (select my_household_ids()));

create policy "select household members" on household_members
  for select using (household_id in (select my_household_ids()));
create policy "insert self as member" on household_members
  for insert with check (user_id = auth.uid());

create policy "manage tasks in own household" on tasks
  for all using (household_id in (select my_household_ids()))
  with check (household_id in (select my_household_ids()));

create policy "manage events in own household" on calendar_events
  for all using (household_id in (select my_household_ids()))
  with check (household_id in (select my_household_ids()));

create policy "manage important dates in own household" on important_dates
  for all using (household_id in (select my_household_ids()))
  with check (household_id in (select my_household_ids()));

create policy "manage shopping lists in own household" on shopping_lists
  for all using (household_id in (select my_household_ids()))
  with check (household_id in (select my_household_ids()));

create policy "manage shopping items via list" on shopping_items
  for all using (list_id in (select id from shopping_lists where household_id in (select my_household_ids())))
  with check (list_id in (select id from shopping_lists where household_id in (select my_household_ids())));

create policy "manage notes in own household" on notes
  for all using (household_id in (select my_household_ids()))
  with check (household_id in (select my_household_ids()));

create policy "manage own push subscriptions" on push_subscriptions
  for all using (
    household_member_id in (select id from household_members where user_id = auth.uid())
  )
  with check (
    household_member_id in (select id from household_members where user_id = auth.uid())
  );
