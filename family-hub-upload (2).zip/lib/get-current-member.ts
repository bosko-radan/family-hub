import { createClient } from "@/lib/supabase/server";
import type { HouseholdMember } from "@/lib/supabase/types";

// Resolves the logged-in auth user to their household_member row — the
// record that actually carries display name, avatar color, and household
// scoping. Called once per request from the (app) layout rather than from
// every page, so the header and any page-level logic share one query.
export async function getCurrentMember(): Promise<HouseholdMember | null> {
  const supabase = await createClient();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("household_members")
    .select("*")
    .eq("user_id", user.id)
    .single();

  return data ?? null;
}
