import { createClient } from "@/lib/supabase/server";
import type { HouseholdMember } from "@/lib/supabase/types";

// Fetches every member of the current user's household — used wherever a
// card needs to resolve an assigned_to id into a display name and avatar
// color. Two rows for this product (you and your partner), so this is a
// cheap, single small query rather than something worth caching further.
export async function getHouseholdMembers(): Promise<HouseholdMember[]> {
  const supabase = await createClient();
  const { data } = await supabase.from("household_members").select("*");
  return data ?? [];
}
