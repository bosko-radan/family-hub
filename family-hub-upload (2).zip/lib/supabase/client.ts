import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/lib/supabase/types";

// Used inside client components ("use client") for interactive actions —
// form submissions, checkbox toggles, anything triggered by a user event
// after the page has already rendered. Safe to call repeatedly; the
// underlying client is cheap to construct and Supabase handles session
// state internally via cookies set by the server client below.
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
