import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/lib/supabase/types";

// Used inside server components, route handlers, and server actions.
// Reads the session from request cookies so the Today view (and anything
// else doing a server-side fetch before render) can run RLS-scoped queries
// without an extra client-side round trip.
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // setAll is called from a Server Component during render, where
            // Next.js disallows mutating cookies. Safe to ignore here as
            // long as middleware (see middleware.ts) refreshes the session
            // on every request.
          }
        },
      },
    }
  );
}
