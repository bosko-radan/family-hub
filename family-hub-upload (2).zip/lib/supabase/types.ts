// Mirrors the schema in supabase/migrations/. In a real deployment these
// would be regenerated automatically via `supabase gen types typescript`
// after every migration so the types never drift from the database — see
// the note in README.md. Hand-written here to match migrations 0001-0003.

export type AvatarColor = "accent" | "pro";
export type DateCategory = "birthday" | "anniversary" | "vehicle" | "health" | "general";

export type HouseholdMember = {
  id: string;
  household_id: string;
  user_id: string;
  display_name: string;
  avatar_color: AvatarColor;
  created_at: string;
};

export type Task = {
  id: string;
  household_id: string;
  title: string;
  notes: string | null;
  due_date: string | null;
  is_recurring: boolean;
  recurrence_rule: string | null;
  assigned_to: string | null;
  assigned_to_everyone: boolean;
  completed_at: string | null;
  last_completed_for_date: string | null;
  created_by: string | null;
  created_at: string;
};

export type CalendarEvent = {
  id: string;
  household_id: string;
  title: string;
  starts_at: string;
  ends_at: string | null;
  reminder_minutes_before: number | null;
  assigned_to: string | null;
  assigned_to_everyone: boolean;
  source_important_date_id: string | null;
  created_by: string | null;
  created_at: string;
};

export type ImportantDate = {
  id: string;
  household_id: string;
  title: string;
  date: string;
  recurrence: "yearly" | "none";
  remind_days_before: number;
  category: DateCategory;
  event_time: string | null;
  event_duration_minutes: number;
  created_by: string | null;
  created_at: string;
};

export type ShoppingList = {
  id: string;
  household_id: string;
  name: string;
  created_at: string;
};

export type ShoppingItem = {
  id: string;
  list_id: string;
  name: string;
  quantity: string | null;
  checked_at: string | null;
  sort_order: number;
  added_by: string | null;
  created_at: string;
};

export type Note = {
  id: string;
  household_id: string;
  content: string;
  pinned: boolean;
  created_by: string | null;
  created_at: string;
  updated_at: string;
};

// Minimal Database shape so createBrowserClient/createServerClient stay
// type-safe without depending on the full Supabase-generated surface.
// Insert/Update are required alongside Row — supabase-js's generic
// PostgrestQueryBuilder<Database, TableName> uses all three to resolve the
// return type of .select()/.update(), and a missing Insert/Update collapses
// the inferred row type to `never` even though only Row is read here.
export type Database = {
  __InternalSupabase: {
    PostgrestVersion: "12";
  };
  public: {
    Tables: {
      household_members: {
        Row: HouseholdMember;
        Insert: Partial<HouseholdMember> & Pick<HouseholdMember, "household_id" | "user_id" | "display_name">;
        Update: Partial<HouseholdMember>;
        Relationships: [];
      };
      tasks: {
        Row: Task;
        Insert: Partial<Task> & Pick<Task, "household_id" | "title">;
        Update: Partial<Task>;
        Relationships: [];
      };
      calendar_events: {
        Row: CalendarEvent;
        Insert: Partial<CalendarEvent> & Pick<CalendarEvent, "household_id" | "title" | "starts_at">;
        Update: Partial<CalendarEvent>;
        Relationships: [];
      };
      important_dates: {
        Row: ImportantDate;
        Insert: Partial<ImportantDate> & Pick<ImportantDate, "household_id" | "title" | "date">;
        Update: Partial<ImportantDate>;
        Relationships: [];
      };
      shopping_lists: {
        Row: ShoppingList;
        Insert: Partial<ShoppingList> & Pick<ShoppingList, "household_id">;
        Update: Partial<ShoppingList>;
        Relationships: [];
      };
      shopping_items: {
        Row: ShoppingItem;
        Insert: Partial<ShoppingItem> & Pick<ShoppingItem, "list_id" | "name">;
        Update: Partial<ShoppingItem>;
        Relationships: [];
      };
      notes: {
        Row: Note;
        Insert: Partial<Note> & Pick<Note, "household_id" | "content">;
        Update: Partial<Note>;
        Relationships: [];
      };
      households: {
        Row: { id: string; name: string; created_at: string };
        Insert: { id?: string; name?: string; created_at?: string };
        Update: { id?: string; name?: string; created_at?: string };
        Relationships: [];
      };
      household_invites: {
        Row: {
          id: string;
          household_id: string;
          code: string;
          created_by: string | null;
          expires_at: string;
          redeemed_at: string | null;
          redeemed_by: string | null;
          created_at: string;
        };
        Insert: {
          household_id: string;
          code: string;
          created_by?: string | null;
        };
        Update: {
          redeemed_at?: string | null;
          redeemed_by?: string | null;
        };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: {
      redeem_household_invite: {
        Args: {
          invite_code: string;
          member_display_name: string;
          member_avatar_color: string;
        };
        Returns: string;
      };
    };
  };
};
