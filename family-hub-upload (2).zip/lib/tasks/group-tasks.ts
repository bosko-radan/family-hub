import { isDueOnDate, type RecurrenceRule } from "@/lib/tasks/recurrence";
import type { Task } from "@/lib/supabase/types";

export interface TaskGroups {
  overdue: Task[];
  today: Task[];
  tomorrow: Task[];
  later: Task[];
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

function tomorrowStr() {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
}

// Groups one-off and recurring tasks into the four Tasks-view buckets.
// A recurring task is "overdue" only if it was due on a past occurrence
// and not completed for that specific cycle — completing a recurring task
// today doesn't retroactively complete yesterday's missed occurrence,
// it just stops it from showing as overdue going forward (see schema note
// on last_completed_for_date: this is a deliberate simplification, not a
// full per-occurrence history).
export function groupTasks(tasks: Task[]): TaskGroups {
  const today = todayStr();
  const tomorrow = tomorrowStr();

  const groups: TaskGroups = { overdue: [], today: [], tomorrow: [], later: [] };

  for (const task of tasks) {
    if (!task.due_date) continue;

    if (task.is_recurring) {
      const rule = (task.recurrence_rule ?? "daily") as RecurrenceRule;
      const doneForToday = task.last_completed_for_date === today;

      if (isDueOnDate(rule, task.due_date, today) && !doneForToday) {
        groups.today.push(task);
      } else if (isDueOnDate(rule, task.due_date, tomorrow)) {
        groups.tomorrow.push(task);
      }
      // Recurring tasks never show as "overdue" or "later" — the next
      // occurrence is what matters, not a missed prior one piling up.
      continue;
    }

    if (task.completed_at) continue;

    if (task.due_date < today) {
      groups.overdue.push(task);
    } else if (task.due_date === today) {
      groups.today.push(task);
    } else if (task.due_date === tomorrow) {
      groups.tomorrow.push(task);
    } else {
      groups.later.push(task);
    }
  }

  groups.later.sort((a, b) => (a.due_date! < b.due_date! ? -1 : 1));

  return groups;
}
