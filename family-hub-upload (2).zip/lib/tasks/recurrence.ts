// Recurrence is one of three fixed rules (daily/weekly/monthly), stored as
// a plain string in recurrence_rule rather than a full RRULE — matches the
// product decision to keep this simple rather than building a custom-
// interval scheduler. due_date is treated as the rule's anchor date: a
// weekly task due on a Monday recurs every Monday from then on.
export type RecurrenceRule = "daily" | "weekly" | "monthly";

export function isDueOnDate(
  rule: RecurrenceRule,
  anchorDate: string,
  targetDate: string
): boolean {
  const anchor = new Date(anchorDate);
  const target = new Date(targetDate);
  if (target < anchor) return false;

  if (rule === "daily") return true;

  if (rule === "weekly") {
    return anchor.getDay() === target.getDay();
  }

  // monthly: same day-of-month, clamped for short months (e.g. anchor on
  // the 31st still fires on Feb 28/29 rather than being silently skipped).
  const lastDayOfTargetMonth = new Date(target.getFullYear(), target.getMonth() + 1, 0).getDate();
  const expectedDay = Math.min(anchor.getDate(), lastDayOfTargetMonth);
  return target.getDate() === expectedDay;
}
