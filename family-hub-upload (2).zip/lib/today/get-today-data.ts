import { createClient } from "@/lib/supabase/server";
import type { Task, CalendarEvent, ImportantDate } from "@/lib/supabase/types";

export interface TodayData {
  overdueTasks: Task[];
  todayEvents: CalendarEvent[];
  tasksToday: Task[];
  upcomingDates: ImportantDate[];
}

function startOfTodayISO() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

function endOfTodayISO() {
  const d = new Date();
  d.setHours(23, 59, 59, 999);
  return d.toISOString();
}

function todayDateOnly() {
  return new Date().toISOString().slice(0, 10);
}

// Aggregates three independent tables into the four Today-view sections.
// This intentionally is NOT one SQL query — overdue tasks, today's events,
// today's tasks, and upcoming dates have different filter shapes, and
// combining them into one query would mean a much harder-to-read OR/UNION
// mess for marginal benefit at this data volume (two users, a few dozen
// rows). Three parallel queries via Promise.all keeps each one simple and
// keeps the latency to roughly one round trip, not three sequential ones.
//
// NOTE: recurring tasks are not yet expanded from recurrence_rule here —
// this reads only literal due_date rows. Recurrence expansion is planned
// for the Tasks module build (see project plan) since it needs the same
// logic there; duplicating a partial version here would just create two
// places to keep in sync.
export async function getTodayData(): Promise<TodayData> {
  const supabase = await createClient();
  const today = todayDateOnly();

  const [tasksResult, eventsResult, datesResult] = await Promise.all([
    supabase
      .from("tasks")
      .select("*")
      .is("completed_at", null)
      .not("due_date", "is", null)
      .lte("due_date", today)
      .order("due_date", { ascending: true }),
    supabase
      .from("calendar_events")
      .select("*")
      .gte("starts_at", startOfTodayISO())
      .lte("starts_at", endOfTodayISO())
      .order("starts_at", { ascending: true }),
    supabase
      .from("important_dates")
      .select("*")
      .order("date", { ascending: true }),
  ]);

  const tasks = tasksResult.data ?? [];
  const overdueTasks = tasks.filter((t) => t.due_date! < today);
  const tasksToday = tasks.filter((t) => t.due_date === today);

  // Important dates store a single calendar date with no year context for
  // recurring ones, so "upcoming within 7 days" is computed in JS against
  // this year's (and, near year-end, next year's) occurrence rather than
  // pushed into SQL date arithmetic that would need to special-case the
  // `recurrence = 'yearly'` wraparound anyway.
  const now = new Date();
  const upcomingDates = (datesResult.data ?? []).filter((d) => {
    const next = nextOccurrence(d.date, d.recurrence, now);
    const daysUntil = Math.ceil((next.getTime() - now.getTime()) / 86_400_000);
    return daysUntil >= 0 && daysUntil <= 7;
  });

  return {
    overdueTasks,
    todayEvents: eventsResult.data ?? [],
    tasksToday,
    upcomingDates,
  };
}

function nextOccurrence(dateStr: string, recurrence: "yearly" | "none", from: Date): Date {
  const original = new Date(dateStr);
  if (recurrence === "none") return original;

  const candidate = new Date(from.getFullYear(), original.getMonth(), original.getDate());
  if (candidate < from) {
    candidate.setFullYear(candidate.getFullYear() + 1);
  }
  return candidate;
}
