import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

// Standard shadcn/ui-style helper: clsx handles conditional classes,
// twMerge resolves Tailwind class conflicts (e.g. two different `p-`
// values) by keeping only the last one instead of letting both apply.
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
